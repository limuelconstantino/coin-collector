extends Area2D
## A falling coin. Emits collected when the player touches it and missed when it falls off screen.

signal collected(points: int, is_golden: bool)
signal missed

@export var fall_speed: float = 120.0
@export var golden: bool = false

var _consumed := false


func _ready() -> void:
    add_to_group("coins")
    add_to_group("fallers")
    # OS CONCEPT: Interrupts. These callbacks run only when the signal fires, not every frame.
    body_entered.connect(_on_body_entered)
    $VisibleOnScreenNotifier2D.screen_exited.connect(_on_screen_exited)


# OS CONCEPT: CPU scheduling. Per-frame logic in _process(); delta keeps the fall speed the same at any frame rate.
func _process(delta: float) -> void:
    position.y += fall_speed * delta


func _on_body_entered(body: Node2D) -> void:
    if _consumed or not body.is_in_group("player"):
        return
    _consumed = true
    collected.emit(5 if golden else 1, golden)
    # OS CONCEPT: Memory management. Free the coin as soon as it is used up (collected).
    queue_free()


# OS CONCEPT: Memory management. Free the coin once it leaves the screen so nodes don't pile up.
func _on_screen_exited() -> void:
    if _consumed:
        return
    _consumed = true
    missed.emit()
    if GameState.leak_test:
        # Leak test (F3): deliberately keep the node alive so the Monitors tab shows the growth.
        set_process(false)
        hide()
        set_deferred("monitoring", false)
    else:
        queue_free()


## Used by the level to remove coins at the end of a round without counting them as missed.
func dismiss() -> void:
    _consumed = true
    queue_free()


func _draw() -> void:
    var coin_color := Color(1.0, 0.72, 0.12) if golden else Color.GOLD
    draw_circle(Vector2.ZERO, 13.0, coin_color)
    draw_circle(Vector2.ZERO, 8.0, Color(1.0, 0.92, 0.25))
    draw_circle(Vector2.ZERO, 3.0, Color(1.0, 0.72, 0.12))
    if golden:
        draw_arc(Vector2.ZERO, 15.0, 0.0, TAU, 32, Color(1.0, 0.94, 0.55), 2.0)
