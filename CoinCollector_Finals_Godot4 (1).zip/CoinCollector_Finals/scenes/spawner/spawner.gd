extends Node2D
## Creates coins (and, in harder levels, bombs) at runtime from their scenes.

signal object_spawned(obj: Node)

@export var coin_scene: PackedScene
@export var bomb_scene: PackedScene
@export_range(0.0, 1.0) var bomb_chance := 0.0
@export_range(0.0, 1.0) var golden_chance := 0.12
@export var start_interval := 1.35
@export var min_interval := 0.48
@export var ramp_per_second := 0.008
@export var speed_bonus_cap := 95.0

var elapsed := 0.0


func _ready() -> void:
    $SpawnTimer.wait_time = start_interval
    # OS CONCEPT: Interrupts. The timer's timeout signal triggers a spawn; nothing polls the clock.
    $SpawnTimer.timeout.connect(_on_spawn_timer_timeout)


func _process(delta: float) -> void:
    elapsed += delta
    # The game gets harder over time: spawns speed up until they reach min_interval.
    $SpawnTimer.wait_time = maxf(min_interval, start_interval - elapsed * ramp_per_second)


# OS CONCEPT: Processes and programs. coin.tscn / bomb.tscn are the "programs"; each instance is a running "process".
func _on_spawn_timer_timeout() -> void:
    var is_bomb := bomb_scene != null and randf() < bomb_chance
    var obj = (bomb_scene if is_bomb else coin_scene).instantiate()
    obj.position = Vector2(randf_range(24.0, get_viewport_rect().size.x - 24.0), -26.0)
    obj.fall_speed = randf_range(95.0, 145.0) + minf(elapsed * 1.4, speed_bonus_cap)
    if not is_bomb:
        obj.golden = randf() < golden_chance
    add_child(obj)
    object_spawned.emit(obj)


func stop() -> void:
    $SpawnTimer.stop()
    set_process(false)
