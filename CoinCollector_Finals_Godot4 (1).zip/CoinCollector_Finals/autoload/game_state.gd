extends Node
## Small global holder: which level to load next, plus the memory-test switch.

const MAIN_MENU := "res://scenes/ui/main_menu.tscn"
const LOADING_SCREEN := "res://scenes/ui/loading_screen.tscn"
const LEVELS: Array[String] = [
    "res://scenes/levels/level_1.tscn",
    "res://scenes/levels/level_2.tscn",
]

var next_level_path: String = LEVELS[0]
## F3 in game: objects that leave the screen are NOT freed (used to measure a leak for the memory report).
var leak_test := false


func go_to_level(level_number: int) -> void:
    next_level_path = LEVELS[clampi(level_number, 1, LEVELS.size()) - 1]
    get_tree().paused = false
    get_tree().change_scene_to_file(LOADING_SCREEN)


func level_count() -> int:
    return LEVELS.size()
