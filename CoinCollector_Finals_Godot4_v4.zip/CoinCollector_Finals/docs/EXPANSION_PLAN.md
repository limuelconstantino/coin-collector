# Expansion Plan - Coin Collector

**Title / genre:** Coin Collector - arcade catcher.

**Midterm version:** A single scene where coins fall and the player catches them. It had lives, golden coins, combos,
pause/restart, a high score saved to a ConfigFile and a thread demo on the T key.

**Finals additions**
- Main menu, loading screen (background-threaded level load), HUD scene, win/lose screens with Restart / Next / Menu.
- **5 levels, easy to hard:** 1 Coin Rain (coins only), 2 Bomb Storm (bombs, faster player), 3 Twilight Drift, 4 Meteor Rain, 5 Chaos Finale. Each level raises bombs, fall speed, spawn rate and player speed.
- New mechanic: **power-ups** (shield, magnet, slow-mo) from `powerup.tscn`.
- New mechanic: **dash** (Space/Shift) with a cooldown.
- Folder restructure, named input actions, sound effects, SaveManager autoload (JSON in `user://`), live memory monitor (F2) and leak test (F3).

## Audit table

| # | OS concept | Already in midterm? | Where now (script / function) | What I added |
|---|-----------|---------------------|-------------------------------|--------------|
| 1 | Processes and programs | Yes | `spawner.gd` / `_on_spawn_timer_timeout()` | Moved into a Spawner scene + Timer; also spawns bombs |
| 2 | CPU scheduling | Yes | `player.gd` / `_physics_process()`, `coin.gd` / `_process()`, `level_base.gd` / `_process()` | Dash timers using `delta` |
| 3 | Interrupts | Yes | `coin.gd`, `bomb.gd`, `spawner.gd`, `level_base.gd` (signals) | Custom signals `score_changed`, `lives_changed`, `combo_changed`, `level_finished` |
| 4 | I/O management | Yes | `player.gd` (polling), `hud.gd` / `_unhandled_input()` | Named input actions (Input Map) instead of raw keys |
| 5 | Memory management | Partly | `coin.gd` / `_on_screen_exited()`, `bomb.gd` | `VisibleOnScreenNotifier2D`, leak test (F3), memory monitor (F2), memory report |
| 6 | File systems | Partly | `autoload/save_manager.gd` | JSON save in `user://save.json`, safe on missing/broken file; saves score, combo, unlocked level |
| 7 | Threads | Partly | `loading_screen.gd` / `_ready()`; `level_base.gd` / `_start_worker_thread()` | Threaded level loading + a Thread/Mutex demo (extra credit) |
| 8 | The OS as a platform | No | Export build | Export to Windows (see README) |
