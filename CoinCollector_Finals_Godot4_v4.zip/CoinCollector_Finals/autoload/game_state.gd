extends Node
## Small global holder: which level to load next, plus the memory-test switch.

const MAIN_MENU := "res://scenes/ui/main_menu.tscn"
const LOADING_SCREEN := "res://scenes/ui/loading_screen.tscn"
const LEVELS: Array[String] = [
    "res://scenes/levels/level_1.tscn",
    "res://scenes/levels/level_2.tscn",
    "res://scenes/levels/level_3.tscn",
    "res://scenes/levels/level_4.tscn",
    "res://scenes/levels/level_5.tscn",
]
const LEVEL_NAMES: Array[String] = ["Coin Rain", "Bomb Storm", "Twilight Drift", "Meteor Rain", "Chaos Finale"]

var next_level_path: String = LEVELS[0]
## F3 in game: objects that leave the screen are NOT freed (used to measure a leak for the memory report).
var leak_test := false
## Multiplier for how fast coins/bombs/power-ups fall (the slow-motion power-up sets this to 0.5).
var fall_scale := 1.0


func go_to_level(level_number: int) -> void:
    next_level_path = LEVELS[clampi(level_number, 1, LEVELS.size()) - 1]
    get_tree().paused = false
    get_tree().change_scene_to_file(LOADING_SCREEN)


func level_count() -> int:
    return LEVELS.size()
