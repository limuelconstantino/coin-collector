extends "res://scenes/levels/level_base.gd"
## Level 2: Bomb Storm. Medium: bombs appear; player is faster (380).
## (All numbers are set in the Inspector: root node for score/speed, Spawner node for spawn settings.)
