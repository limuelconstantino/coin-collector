extends "res://scenes/levels/level_base.gd"
## Level 4: Meteor Rain. Hard: faster, crowded, more bombs.
## (All numbers are set in the Inspector: root node for score/speed, Spawner node for spawn settings.)
