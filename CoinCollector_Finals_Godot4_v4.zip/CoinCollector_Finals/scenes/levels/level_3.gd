extends "res://scenes/levels/level_base.gd"
## Level 3: Twilight Drift. Medium-hard: more bombs, more golden coins and power-ups.
## (All numbers are set in the Inspector: root node for score/speed, Spawner node for spawn settings.)
