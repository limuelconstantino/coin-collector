extends "res://scenes/levels/level_base.gd"
## Level 5: Chaos Finale. Very hard: final level.
## (All numbers are set in the Inspector: root node for score/speed, Spawner node for spawn settings.)
