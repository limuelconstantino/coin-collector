extends "res://scenes/levels/level_base.gd"
## Level 1: Coin Rain. Easy: coins only, slow.
## (All numbers are set in the Inspector: root node for score/speed, Spawner node for spawn settings.)
