extends Control

@onready var _start_button: Button = %StartButton
@onready var _level_grid: HBoxContainer = %LevelGrid
@onready var _quit_button: Button = %QuitButton
@onready var _stats_label: Label = %StatsLabel


func _ready() -> void:
    GameState.leak_test = false
    _start_button.pressed.connect(_on_start_pressed)
    _quit_button.pressed.connect(_on_quit_pressed)

    # Reads the save file; a missing or broken file just gives the defaults.
    var data := SaveManager.load_game()
    var unlocked := int(data["highest_level"])
    _stats_label.text = "High score: %d     Best combo: x%d     Levels unlocked: %d/%d" % [
        int(data["high_score"]), int(data["best_combo"]), unlocked, GameState.level_count()]

    # One button per level, created at runtime. Locked levels are disabled.
    for i in GameState.level_count():
        var level_number := i + 1
        var button := Button.new()
        button.text = str(level_number)
        button.custom_minimum_size = Vector2(52, 44)
        button.tooltip_text = GameState.LEVEL_NAMES[i]
        button.disabled = level_number > unlocked
        button.pressed.connect(GameState.go_to_level.bind(level_number))
        _level_grid.add_child(button)
    _start_button.grab_focus()


func _on_start_pressed() -> void:
    GameState.go_to_level(1)


func _on_quit_pressed() -> void:
    get_tree().quit()
