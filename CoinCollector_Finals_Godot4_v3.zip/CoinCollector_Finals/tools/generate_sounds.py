"""Generates the game's simple sound effects (original, royalty-free).
Run:  python3 tools/generate_sounds.py   (writes into assets/audio/)"""
import wave, math, struct, random, os
RATE = 22050
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets", "audio")

def tone(freq, dur, vol=0.5, shape="sine", slide=0.0):
    n = int(RATE * dur); out = []
    for i in range(n):
        t = i / RATE
        f = freq + slide * (t / dur)
        ph = 2 * math.pi * f * t
        if shape == "noise":
            s = random.uniform(-1, 1)
        elif shape == "square":
            s = 1.0 if math.sin(ph) > 0 else -1.0
        else:
            s = math.sin(ph)
        env = min(1, i / 200) * (1 - i / n) ** 1.5
        out.append(s * vol * env)
    return out

def save(name, samples):
    os.makedirs(OUT, exist_ok=True)
    with wave.open(os.path.join(OUT, name), "w") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(RATE)
        w.writeframes(b"".join(struct.pack("<h", int(max(-1, min(1, s)) * 32767)) for s in samples))

save("coin.wav", tone(880, 0.06) + tone(1320, 0.12))
save("golden.wav", tone(660, 0.07) + tone(880, 0.07) + tone(1320, 0.07) + tone(1760, 0.18))
save("hit.wav", tone(180, 0.28, 0.6, "square", slide=-120))
save("miss.wav", tone(300, 0.2, 0.4, "sine", slide=-150))
save("win.wav", tone(523, 0.12) + tone(659, 0.12) + tone(784, 0.12) + tone(1047, 0.35))
save("lose.wav", tone(392, 0.2) + tone(330, 0.2) + tone(262, 0.2) + tone(196, 0.45))
