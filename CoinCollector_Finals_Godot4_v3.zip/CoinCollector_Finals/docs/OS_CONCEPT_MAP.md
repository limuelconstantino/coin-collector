# OS Concept Map

Search the project for `# OS CONCEPT:` to find every marked line quickly.

| # | Concept | File / function | How the game shows it | Why it matters |
|---|---------|-----------------|-----------------------|----------------|
| 1 | Processes and programs | `scenes/spawner/spawner.gd` / `_on_spawn_timer_timeout()` | `coin.tscn` / `bomb.tscn` are the program; every `instantiate()` is a running process | One program image, many independent running instances |
| 2 | CPU scheduling | `player.gd` `_physics_process()`; `coin.gd`, `bomb.gd`, `level_base.gd` `_process()` | Fixed-rate physics vs. per-frame logic, `delta` for time-based change | The engine schedules work in time slices; delta keeps behaviour independent of speed |
| 3 | Interrupts | `coin.gd`, `bomb.gd`, `spawner.gd`, `level_base.gd` | `body_entered`, `screen_exited`, `timeout`, custom `score_changed` etc. | Code runs when an event happens instead of polling |
| 4 | I/O management | `player.gd` (poll); `hud.gd` `_unhandled_input()` (event) | Movement polled every tick; pause/restart handled once per press | Polling suits held keys; events suit one-time actions |
| 5 | Memory management | `coin.gd` / `bomb.gd` `_on_screen_exited()`, `queue_free()` | Off-screen and used-up objects are freed; F2 shows node count | Unfreed objects are a memory leak |
| 6 | File systems | `autoload/save_manager.gd` | JSON in `user://save.json`, handles missing/corrupt file | `res://` is read-only when exported |
| 7 | Threads | `scenes/ui/loading_screen.gd`; `level_base.gd` | `load_threaded_request` loads the level off the main thread; Mutex guards shared progress | The UI stays responsive; shared data needs a lock |
| 8 | The OS as a platform | Exported build | `.exe` runs without the editor; `user://` maps to an OS folder | The game depends on OS services for files, input, windows |

*Practice explaining each row in your own words, and be ready to make a small change live.*
