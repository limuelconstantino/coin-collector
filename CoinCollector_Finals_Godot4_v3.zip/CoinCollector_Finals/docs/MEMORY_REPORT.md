# Memory Report

> Fill in the numbers yourself. Only measured values from your own runs count.

## How to measure (2 minutes each)
**Without freeing:** run a level, press **F3** (Leak test ON: off-screen objects are kept, lives and winning are disabled
so the run can last), press **F2** to show the monitor. After 2 minutes write down the numbers.
You can also read them in the editor under Debugger > Monitors (Object > Nodes, Object > Orphan Nodes, Memory > Static).

**With freeing:** restart the level (F3 off, which is the default), but to keep playing for 2 minutes
while testing you can catch coins and dodge bombs, or temporarily set `start_lives` high on the level root.

| Measurement (after 2 minutes) | Without freeing | With freeing |
|-------------------------------|-----------------|--------------|
| Object > Nodes                |                 |              |
| Object > Orphan Nodes         |                 |              |
| Memory > Static               |                 |              |

## Explanation (2-3 sentences)
- What changed:
- Why it changed:
- What would happen after an hour without freeing:

*Code that frees objects:* `coin.gd` / `bomb.gd` -> `_on_screen_exited()` and `queue_free()`.
