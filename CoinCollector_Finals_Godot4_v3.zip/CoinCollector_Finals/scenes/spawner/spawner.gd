extends Node2D
## Creates coins (and, in harder levels, bombs) at runtime from their scenes.

signal object_spawned(obj: Node)

@export var coin_scene: PackedScene
@export var bomb_scene: PackedScene
@export var powerup_scene: PackedScene
@export_range(0.0, 1.0) var powerup_chance := 0.08
@export_range(0.0, 1.0) var bomb_chance := 0.0
@export_range(0.0, 1.0) var golden_chance := 0.12
@export var start_interval := 1.35
@export var min_interval := 0.48
@export var ramp_per_second := 0.008
@export var min_fall_speed := 65.0
@export var max_fall_speed := 100.0
@export var speed_gain_per_second := 0.9
@export var speed_bonus_cap := 60.0

var elapsed := 0.0


func _ready() -> void:
    $SpawnTimer.wait_time = start_interval
    # OS CONCEPT: Interrupts. The timer's timeout signal triggers a spawn; nothing polls the clock.
    $SpawnTimer.timeout.connect(_on_spawn_timer_timeout)


func _process(delta: float) -> void:
    elapsed += delta
    # The game gets harder over time: spawns speed up until they reach min_interval.
    $SpawnTimer.wait_time = maxf(min_interval, start_interval - elapsed * ramp_per_second)


# OS CONCEPT: Processes and programs. coin / bomb / powerup .tscn are the "programs"; each instance is a running "process".
func _on_spawn_timer_timeout() -> void:
    var scene: PackedScene = coin_scene
    var what := "coin"
    if powerup_scene != null and randf() < powerup_chance:
        scene = powerup_scene
        what = "powerup"
    elif bomb_scene != null and randf() < bomb_chance:
        scene = bomb_scene
        what = "bomb"

    var obj = scene.instantiate()
    obj.position = Vector2(randf_range(24.0, get_viewport_rect().size.x - 24.0), -26.0)
    obj.fall_speed = randf_range(min_fall_speed, max_fall_speed) + minf(elapsed * speed_gain_per_second, speed_bonus_cap)
    if what == "coin":
        obj.golden = randf() < golden_chance
    elif what == "powerup":
        obj.kind = ["shield", "magnet", "slow"].pick_random()
    add_child(obj)
    object_spawned.emit(obj)


func stop() -> void:
    $SpawnTimer.stop()
    set_process(false)
