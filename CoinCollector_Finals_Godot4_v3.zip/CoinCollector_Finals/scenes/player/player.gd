extends CharacterBody2D
## The player: moves with named input actions and can dash (new since the midterm).

@export var speed: float = 290.0
@export var dash_speed: float = 720.0
@export var dash_duration: float = 0.14
@export var dash_cooldown: float = 0.9

var _dash_time_left := 0.0
var _cooldown_left := 0.0
var _last_direction := Vector2.RIGHT
var _shield_on := false
var _magnet_on := false

const MAGNET_RADIUS := 220.0
const MAGNET_PULL := 260.0


func _ready() -> void:
    add_to_group("player")


# OS CONCEPT: CPU scheduling. Physics runs at a fixed rate in _physics_process(); delta makes timers frame-rate independent.
func _physics_process(delta: float) -> void:
    # OS CONCEPT: I/O management. Polling: the input state is checked every physics tick.
    var direction := Input.get_vector("move_left", "move_right", "move_up", "move_down")
    if direction != Vector2.ZERO:
        _last_direction = direction

    _cooldown_left = maxf(_cooldown_left - delta, 0.0)
    if _dash_time_left > 0.0:
        _dash_time_left -= delta
        velocity = _last_direction * dash_speed
        if _dash_time_left <= 0.0:
            modulate.a = 1.0
    else:
        velocity = direction * speed
        if Input.is_action_just_pressed("dash") and _cooldown_left <= 0.0:
            _dash_time_left = dash_duration
            _cooldown_left = dash_cooldown
            modulate.a = 0.55

    move_and_slide()
    if _magnet_on:
        _pull_coins(delta)
    var screen := get_viewport_rect().size
    position.x = clampf(position.x, 20.0, screen.x - 20.0)
    position.y = clampf(position.y, 140.0, screen.y - 24.0)


func set_shield(on: bool) -> void:
    _shield_on = on
    queue_redraw()


func set_magnet(on: bool) -> void:
    _magnet_on = on
    queue_redraw()


## Magnet power-up: drags nearby coins toward the player (hidden "leak test" coins are skipped).
func _pull_coins(delta: float) -> void:
    for coin in get_tree().get_nodes_in_group("coins"):
        if not coin.visible:
            continue
        var to_player: Vector2 = global_position - coin.global_position
        if to_player.length() < MAGNET_RADIUS:
            coin.global_position += to_player.normalized() * MAGNET_PULL * delta


## Red flash used when a bomb hits the player.
func flash() -> void:
    var tween := create_tween()
    modulate = Color(1.0, 0.3, 0.3)
    tween.tween_property(self, "modulate", Color.WHITE, 0.35)


func _draw() -> void:
    if _shield_on:
        draw_circle(Vector2.ZERO, 26.0, Color(0.3, 0.6, 1.0, 0.18))
        draw_arc(Vector2.ZERO, 26.0, 0.0, TAU, 32, Color(0.5, 0.75, 1.0), 2.5)
    if _magnet_on:
        draw_arc(Vector2.ZERO, MAGNET_RADIUS, 0.0, TAU, 64, Color(0.95, 0.3, 0.3, 0.25), 2.0)
    draw_circle(Vector2(0, 2), 18.0, Color(0.08, 0.12, 0.2, 0.22))
    draw_circle(Vector2.ZERO, 16.0, Color(0.2, 0.68, 1.0))
    draw_circle(Vector2(-5, -4), 4.0, Color(0.45, 0.85, 1.0))
    draw_circle(Vector2(5, -4), 3.0, Color.WHITE)
    draw_circle(Vector2(5, -4), 1.5, Color(0.1, 0.2, 0.35))
    draw_arc(Vector2(0, 3), 7.0, 0.2, PI - 0.2, 20, Color(0.08, 0.2, 0.35), 2.0)
