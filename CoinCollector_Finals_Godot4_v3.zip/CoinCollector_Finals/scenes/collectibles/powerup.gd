extends Area2D
## A falling power-up: "shield", "magnet" or "slow". Emits picked_up(kind) when the player touches it.

signal picked_up(kind: String)

const COLORS := {
    "shield": Color(0.3, 0.6, 1.0),
    "magnet": Color(0.95, 0.3, 0.3),
    "slow": Color(0.7, 0.4, 1.0),
}
const LETTERS := {"shield": "S", "magnet": "M", "slow": "T"}

@export var fall_speed: float = 110.0
@export var kind: String = "shield"

var _consumed := false


func _ready() -> void:
    add_to_group("fallers")
    # OS CONCEPT: Interrupts. Pick-up and screen-exit are signals, handled only when they happen.
    body_entered.connect(_on_body_entered)
    $VisibleOnScreenNotifier2D.screen_exited.connect(_on_screen_exited)


# OS CONCEPT: CPU scheduling. Per-frame movement in _process(), scaled by delta.
func _process(delta: float) -> void:
    position.y += fall_speed * GameState.fall_scale * delta


func _on_body_entered(body: Node2D) -> void:
    if _consumed or not body.is_in_group("player"):
        return
    _consumed = true
    picked_up.emit(kind)
    # OS CONCEPT: Memory management. Free the power-up as soon as it is used up.
    queue_free()


# OS CONCEPT: Memory management. Free the power-up once it leaves the screen.
func _on_screen_exited() -> void:
    if _consumed:
        return
    _consumed = true
    queue_free()


func dismiss() -> void:
    _consumed = true
    queue_free()


func _draw() -> void:
    var c: Color = COLORS.get(kind, Color.WHITE)
    draw_circle(Vector2.ZERO, 16.0, Color(c.r, c.g, c.b, 0.3))
    draw_circle(Vector2.ZERO, 12.0, c)
    draw_arc(Vector2.ZERO, 16.0, 0.0, TAU, 28, Color.WHITE, 2.0)
    var font := ThemeDB.fallback_font
    draw_string(font, Vector2(-5, 6), LETTERS.get(kind, "?"), HORIZONTAL_ALIGNMENT_LEFT, -1, 16, Color.WHITE)
