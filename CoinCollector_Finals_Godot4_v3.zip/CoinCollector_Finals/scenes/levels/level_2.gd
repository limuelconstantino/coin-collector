extends "res://scenes/levels/level_base.gd"
## Level 2: Bomb Storm. New since the midterm: falling bombs. Dodge them, or use the dash (Space) to slip past.
## (Bomb chance and speed are set on the Spawner node; the target score on the root node.)
