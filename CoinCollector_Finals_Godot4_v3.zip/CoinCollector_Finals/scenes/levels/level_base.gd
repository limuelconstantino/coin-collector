extends Node2D
## Shared game logic for every level: score, lives, combo, win/lose, sound, saving.
## level_1.gd and level_2.gd extend this; the per-level numbers are set in each level's Inspector.

# OS CONCEPT: Interrupts. Custom signals other nodes (the HUD) listen for; they fire only when the value changes.
signal score_changed(new_score: int)
signal lives_changed(new_lives: int)
signal combo_changed(new_combo: int)
signal level_finished(won: bool)

const SFX := {
    "coin": preload("res://assets/audio/coin.wav"),
    "golden": preload("res://assets/audio/golden.wav"),
    "hit": preload("res://assets/audio/hit.wav"),
    "miss": preload("res://assets/audio/miss.wav"),
    "win": preload("res://assets/audio/win.wav"),
    "lose": preload("res://assets/audio/lose.wav"),
}

@export var level_number := 1
@export var level_title := "Level 1"
@export_multiline var intro_text := ""
@export var target_score := 75
@export var start_lives := 3
@export var bg_color := Color(0.06, 0.1, 0.2)

var score := 0
var lives := 0
var combo := 0
var best_combo := 0
var elapsed_time := 0.0
var high_score := 0
var ended := false

var _sfx_players := {}
var _stars := PackedVector2Array()
var _thread: Thread
var _mutex := Mutex.new()
var _shared_progress := 0
var _thread_running := false
var _shield := false
var _magnet_left := 0.0
var _slow_left := 0.0
var _last_powerup_text := ""

# Untyped on purpose: these nodes use members defined by their own scripts (flash(), stop(), update_score()...).
@onready var _player = $Player
@onready var _spawner = $Spawner
@onready var _hud = $HUD


func _ready() -> void:
    add_to_group("game")
    randomize()
    lives = start_lives
    GameState.fall_scale = 1.0

    # Sound effects: one player per effect.
    for key in SFX:
        var p := AudioStreamPlayer.new()
        p.stream = SFX[key]
        add_child(p)
        _sfx_players[key] = p

    # Background decoration.
    for i in 45:
        _stars.append(Vector2(randf_range(0, 800), randf_range(0, 600)))

    # OS CONCEPT: Interrupts. Connecting signals in code: the HUD reacts only when the level emits.
    score_changed.connect(_hud.update_score)
    lives_changed.connect(_hud.update_lives)
    combo_changed.connect(_hud.update_combo)
    level_finished.connect(_on_level_finished)
    _hud.restart_pressed.connect(_on_restart_pressed)
    _hud.menu_pressed.connect(_on_menu_pressed)
    _hud.next_level_pressed.connect(_on_next_level_pressed)
    _spawner.object_spawned.connect(_on_object_spawned)

    high_score = int(SaveManager.load_game()["high_score"])
    _hud.setup(level_title, target_score, high_score, intro_text)
    score_changed.emit(score)
    lives_changed.emit(lives)
    combo_changed.emit(combo)


# OS CONCEPT: CPU scheduling. Per-frame (non-physics) logic lives in _process(); delta makes the clock frame-rate independent.
func _process(delta: float) -> void:
    if not ended:
        elapsed_time += delta
        _hud.update_time(elapsed_time)
    _update_powerups(delta)
    _check_worker_thread()


func _on_object_spawned(obj) -> void:
    # Hook up whichever signals this kind of object has (coins vs. bombs).
    if obj.has_signal("collected"):
        obj.collected.connect(_on_coin_collected)
    if obj.has_signal("missed"):
        obj.missed.connect(_on_coin_missed)
    if obj.has_signal("hit"):
        obj.hit.connect(_on_bomb_hit)
    if obj.has_signal("picked_up"):
        obj.picked_up.connect(_on_powerup_picked)


func _on_powerup_picked(kind: String) -> void:
    if ended:
        return
    match kind:
        "shield":
            _shield = true
            _player.set_shield(true)
        "magnet":
            _magnet_left = 8.0
            _player.set_magnet(true)
        "slow":
            _slow_left = 6.0
            GameState.fall_scale = 0.5
    _play_sfx("golden")


# Power-up timers count down with delta, so they also freeze while the game is paused.
func _update_powerups(delta: float) -> void:
    if _magnet_left > 0.0:
        _magnet_left -= delta
        if _magnet_left <= 0.0:
            _player.set_magnet(false)
    if _slow_left > 0.0:
        _slow_left -= delta
        if _slow_left <= 0.0:
            GameState.fall_scale = 1.0
    var parts: Array[String] = []
    if _shield:
        parts.append("Shield")
    if _magnet_left > 0.0:
        parts.append("Magnet %ds" % ceili(_magnet_left))
    if _slow_left > 0.0:
        parts.append("Slow-mo %ds" % ceili(_slow_left))
    var text := "Power-ups: " + (", ".join(parts) if parts.size() > 0 else "none")
    if text != _last_powerup_text:  # only touch the HUD when the text changes
        _last_powerup_text = text
        _hud.set_powerup_text(text)


func _clear_powerups() -> void:
    _shield = false
    _magnet_left = 0.0
    _slow_left = 0.0
    GameState.fall_scale = 1.0
    _player.set_shield(false)
    _player.set_magnet(false)


func _on_coin_collected(points: int, is_golden: bool) -> void:
    if ended:
        return
    combo += 1
    best_combo = maxi(best_combo, combo)
    score += points + mini(combo - 1, 4)  # combo bonus, up to +4 per coin
    _play_sfx("golden" if is_golden else "coin")
    score_changed.emit(score)
    combo_changed.emit(combo)
    if score >= target_score and not GameState.leak_test:
        _finish(true)


func _on_coin_missed() -> void:
    if ended or not is_inside_tree():
        return
    combo = 0
    combo_changed.emit(combo)
    _play_sfx("miss")
    _lose_life()


func _on_bomb_hit() -> void:
    if ended or not is_inside_tree():
        return
    combo = 0
    combo_changed.emit(combo)
    _player.flash()
    _play_sfx("hit")
    _lose_life()


func _lose_life() -> void:
    if GameState.leak_test:  # lives are switched off while measuring memory
        return
    if _shield:  # the shield absorbs one hit or miss
        _shield = false
        _player.set_shield(false)
        return
    lives -= 1
    lives_changed.emit(lives)
    if lives <= 0:
        _finish(false)


func _finish(won: bool) -> void:
    ended = true
    _spawner.stop()
    get_tree().call_group("fallers", "dismiss")  # clear what's left without counting it as missed
    _clear_powerups()
    _player.set_physics_process(false)
    _player.velocity = Vector2.ZERO
    var reached := level_number
    if won:
        reached = mini(level_number + 1, GameState.level_count())
    SaveManager.record_run(score, best_combo, reached)
    level_finished.emit(won)


func _on_level_finished(won: bool) -> void:
    _play_sfx("win" if won else "lose")
    var is_last := level_number >= GameState.level_count()
    var title := "GAME OVER"
    if won:
        title = "YOU WIN!" if is_last else "LEVEL COMPLETE!"
    var message := "Score: %d    Best combo: x%d    Time: %ds" % [score, best_combo, int(elapsed_time)]
    _hud.show_end(title, message, won and not is_last)


func _on_restart_pressed() -> void:
    get_tree().paused = false
    get_tree().reload_current_scene()


func _on_menu_pressed() -> void:
    if not ended:
        SaveManager.record_run(score, best_combo, level_number)
    get_tree().paused = false
    get_tree().change_scene_to_file(GameState.MAIN_MENU)


func _on_next_level_pressed() -> void:
    GameState.go_to_level(level_number + 1)


func _play_sfx(sfx_name: String) -> void:
    var p: AudioStreamPlayer = _sfx_players.get(sfx_name)
    if p != null:
        p.play()


# OS CONCEPT: I/O management. Event-driven input: runs once when the thread_demo key is pressed.
func _unhandled_input(event: InputEvent) -> void:
    if event.is_action_pressed("thread_demo"):
        _start_worker_thread()


# OS CONCEPT: Threads (extra credit). A real Thread shares data with the main thread, protected by a Mutex.
func _start_worker_thread() -> void:
    if _thread_running:
        return
    _mutex.lock()
    _shared_progress = 0
    _mutex.unlock()
    _thread = Thread.new()
    if _thread.start(_background_work.bind(3000000)) != OK:
        _hud.set_thread_text("Thread couldn't start.")
        return
    _thread_running = true
    _hud.set_thread_text("Thread demo: running...")


func _background_work(iterations: int) -> int:
    var total := 0
    for i in iterations:
        total += i % 7
        if i % 100000 == 0:
            # Without the Mutex the main thread could read _shared_progress while it is half-written.
            _mutex.lock()
            _shared_progress = i * 100 / iterations
            _mutex.unlock()
    return total


func _check_worker_thread() -> void:
    if not _thread_running:
        return
    _mutex.lock()
    var percent := _shared_progress
    _mutex.unlock()
    if _thread.is_alive():
        _hud.set_thread_text("Thread demo: %d%%" % percent)
    else:
        var result: int = _thread.wait_to_finish()
        _thread_running = false
        _hud.set_thread_text("Thread demo done. Result: %d" % result)


func _notification(what: int) -> void:
    # The window was closed mid-run: keep the best score so far.
    if what == NOTIFICATION_WM_CLOSE_REQUEST and not ended:
        SaveManager.record_run(score, best_combo, level_number)


func _exit_tree() -> void:
    GameState.fall_scale = 1.0
    # A started thread must always be joined before it is destroyed.
    if _thread != null and _thread.is_started():
        _thread.wait_to_finish()


func _draw() -> void:
    draw_rect(Rect2(0, 0, 800, 600), bg_color)
    for s in _stars:
        draw_circle(s, 1.5, Color(1, 1, 1, 0.25))
