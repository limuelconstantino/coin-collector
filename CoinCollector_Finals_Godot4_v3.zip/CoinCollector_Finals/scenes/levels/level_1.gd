extends "res://scenes/levels/level_base.gd"
## Level 1: Coin Rain. Catch coins and reach the target score. No hazards.
## (All numbers are set on the root node in the Inspector.)
