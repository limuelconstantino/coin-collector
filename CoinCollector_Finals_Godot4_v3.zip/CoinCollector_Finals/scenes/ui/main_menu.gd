extends Control

@onready var _start_button: Button = %StartButton
@onready var _level_2_button: Button = %Level2Button
@onready var _quit_button: Button = %QuitButton
@onready var _stats_label: Label = %StatsLabel


func _ready() -> void:
    GameState.leak_test = false
    _start_button.pressed.connect(_on_start_pressed)
    _level_2_button.pressed.connect(_on_level_2_pressed)
    _quit_button.pressed.connect(_on_quit_pressed)

    # Reads the save file; a missing or broken file just gives the defaults.
    var data := SaveManager.load_game()
    _stats_label.text = "High score: %d     Best combo: x%d" % [int(data["high_score"]), int(data["best_combo"])]
    var unlocked := int(data["highest_level"]) >= 2
    _level_2_button.disabled = not unlocked
    _level_2_button.text = "Level 2: Bomb Storm" if unlocked else "Level 2 (locked - beat Level 1)"
    _start_button.grab_focus()


func _on_start_pressed() -> void:
    GameState.go_to_level(1)


func _on_level_2_pressed() -> void:
    GameState.go_to_level(2)


func _on_quit_pressed() -> void:
    get_tree().quit()
