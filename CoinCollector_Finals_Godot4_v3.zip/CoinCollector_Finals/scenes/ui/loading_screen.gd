extends Control
## Loads the next level on a background thread while a progress bar fills.

const MIN_SHOW_TIME := 0.5  # keep the screen visible briefly so the bar can be seen

var _level_path: String
var _progress := []
var _elapsed := 0.0
var _failed := false


# OS CONCEPT: Threads. The level loads on a background thread so the game doesn't freeze.
func _ready() -> void:
    _level_path = GameState.next_level_path
    ResourceLoader.load_threaded_request(_level_path)


# OS CONCEPT: CPU scheduling. _process() runs every frame, so the bar keeps updating while the thread works.
func _process(delta: float) -> void:
    if _failed:
        return
    _elapsed += delta
    var status := ResourceLoader.load_threaded_get_status(_level_path, _progress)
    if _progress.size() > 0:
        %ProgressBar.value = _progress[0] * 100.0

    match status:
        ResourceLoader.THREAD_LOAD_FAILED, ResourceLoader.THREAD_LOAD_INVALID_RESOURCE:
            _failed = true
            %LoadingLabel.text = "Could not load the level."
        ResourceLoader.THREAD_LOAD_LOADED:
            if _elapsed >= MIN_SHOW_TIME:
                %ProgressBar.value = 100.0
                var level: PackedScene = ResourceLoader.load_threaded_get(_level_path)
                # Changing scenes happens on the main thread, which owns the scene tree.
                get_tree().change_scene_to_packed(level)
