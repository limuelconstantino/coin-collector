extends CanvasLayer
## Heads-up display, pause menu and end-of-level screen.
## Its Process > Mode is "Always" so it keeps running (and can unpause) while the tree is paused.

signal restart_pressed
signal menu_pressed
signal next_level_pressed
signal pause_changed(is_paused: bool)

var _title := ""
var _target := 0
var _score := 0
var _best := 0
var _lives := 0
var _combo := 0
var _seconds := -1
var _ended := false
var _debug_timer := 0.0

@onready var _status_label: Label = %StatusLabel
@onready var _thread_label: Label = %ThreadLabel
@onready var _powerup_label: Label = %PowerupLabel
@onready var _intro_label: Label = %IntroLabel
@onready var _debug_label: Label = %DebugLabel
@onready var _overlay: ColorRect = %Overlay
@onready var _overlay_title: Label = %OverlayTitle
@onready var _overlay_message: Label = %OverlayMessage
@onready var _resume_button: Button = %ResumeButton
@onready var _next_button: Button = %NextButton
@onready var _restart_button: Button = %RestartButton
@onready var _menu_button: Button = %MenuButton


func _ready() -> void:
    _resume_button.pressed.connect(func(): _set_paused(false))
    _next_button.pressed.connect(func(): next_level_pressed.emit())
    _restart_button.pressed.connect(func(): restart_pressed.emit())
    _menu_button.pressed.connect(func(): menu_pressed.emit())
    _overlay.hide()
    _debug_label.hide()


func setup(title: String, target: int, best: int, intro: String) -> void:
    _title = title
    _target = target
    _best = best
    _intro_label.text = intro
    _refresh()
    # Fade the intro hint away after a few seconds.
    var tween := create_tween()
    tween.tween_interval(5.0)
    tween.tween_property(_intro_label, "modulate:a", 0.0, 1.0)


# These four are connected to the level's custom signals (see level_base.gd).
func update_score(new_score: int) -> void:
    _score = new_score
    _best = maxi(_best, new_score)
    _refresh()


func update_lives(new_lives: int) -> void:
    _lives = new_lives
    _refresh()


func update_combo(new_combo: int) -> void:
    _combo = new_combo
    _refresh()


func update_time(seconds_elapsed: float) -> void:
    if int(seconds_elapsed) != _seconds:  # only redraw when the displayed second changes
        _seconds = int(seconds_elapsed)
        _refresh()


func set_thread_text(text: String) -> void:
    _thread_label.text = text


func set_powerup_text(text: String) -> void:
    _powerup_label.text = text


func show_end(title: String, message: String, show_next: bool) -> void:
    _ended = true
    _show_overlay(title, message, false, show_next)


func _refresh() -> void:
    _status_label.text = "%s\nScore: %d / %d     Best: %d\nLives: %d     Combo: x%d     Time: %ds" % [
        _title, _score, _target, _best, _lives, _combo, maxi(_seconds, 0)]


func _show_overlay(title: String, message: String, show_resume: bool, show_next: bool) -> void:
    _overlay_title.text = title
    _overlay_message.text = message
    _resume_button.visible = show_resume
    _next_button.visible = show_next
    _overlay.show()
    if show_resume:
        _resume_button.grab_focus()
    elif show_next:
        _next_button.grab_focus()
    else:
        _restart_button.grab_focus()


func _set_paused(paused: bool) -> void:
    get_tree().paused = paused
    if paused:
        _show_overlay("PAUSED", "Press P or Esc to resume", true, false)
    else:
        _overlay.hide()
    pause_changed.emit(paused)


# OS CONCEPT: I/O management. Event-driven input: this runs once per key press, not every frame.
func _unhandled_input(event: InputEvent) -> void:
    if event.is_action_pressed("pause") and not _ended:
        _set_paused(not get_tree().paused)
    elif event.is_action_pressed("restart"):
        restart_pressed.emit()
    elif event.is_action_pressed("toggle_debug"):
        _debug_label.visible = not _debug_label.visible
    elif event.is_action_pressed("toggle_leak_test"):
        GameState.leak_test = not GameState.leak_test


func _process(delta: float) -> void:
    if not _debug_label.visible:
        return
    _debug_timer -= delta
    if _debug_timer > 0.0:
        return
    _debug_timer = 0.25
    # The same numbers as the editor's Debugger > Monitors tab, so you can read them in an exported build too.
    _debug_label.text = "FPS: %d\nNodes: %d\nOrphan nodes: %d\nStatic memory: %.2f MB\nLeak test (F3): %s" % [
        Engine.get_frames_per_second(),
        int(Performance.get_monitor(Performance.OBJECT_NODE_COUNT)),
        int(Performance.get_monitor(Performance.OBJECT_ORPHAN_NODE_COUNT)),
        Performance.get_monitor(Performance.MEMORY_STATIC) / 1048576.0,
        "ON  (objects NOT freed, lives off)" if GameState.leak_test else "off"]
