extends Area2D
## A falling bomb (new mechanic in level 2). Touching it costs a life; letting it fall away is safe.

signal hit

@export var fall_speed: float = 120.0

var _consumed := false


func _ready() -> void:
    add_to_group("bombs")
    add_to_group("fallers")
    # OS CONCEPT: Interrupts. Collision and screen-exit are signals, handled only when they happen.
    body_entered.connect(_on_body_entered)
    $VisibleOnScreenNotifier2D.screen_exited.connect(_on_screen_exited)


# OS CONCEPT: CPU scheduling. Per-frame movement in _process(), scaled by delta.
func _process(delta: float) -> void:
    position.y += fall_speed * GameState.fall_scale * delta


func _on_body_entered(body: Node2D) -> void:
    if _consumed or not body.is_in_group("player"):
        return
    _consumed = true
    hit.emit()
    # OS CONCEPT: Memory management. The bomb is destroyed as soon as it explodes.
    queue_free()


# OS CONCEPT: Memory management. Free the bomb once it leaves the screen.
func _on_screen_exited() -> void:
    if _consumed:
        return
    _consumed = true
    if GameState.leak_test:
        set_process(false)
        hide()
        set_deferred("monitoring", false)
    else:
        queue_free()


func dismiss() -> void:
    _consumed = true
    queue_free()


func _draw() -> void:
    draw_line(Vector2(6, -12), Vector2(12, -20), Color(0.75, 0.6, 0.4), 3.0)
    draw_circle(Vector2(13, -21), 4.0, Color(1.0, 0.55, 0.1))
    draw_circle(Vector2.ZERO, 14.0, Color(0.12, 0.12, 0.16))
    draw_circle(Vector2(-5, -5), 4.0, Color(0.4, 0.4, 0.5))
    draw_arc(Vector2.ZERO, 14.0, 0.0, TAU, 28, Color(0.85, 0.15, 0.15), 2.0)
