extends Node
## Saves and loads progress as JSON in user:// (the only writable location in an exported game).

# OS CONCEPT: File systems. user:// is writable; res:// is read-only in an exported game.
const SAVE_PATH := "user://save.json"
const DEFAULT_DATA := {"high_score": 0, "best_combo": 0, "highest_level": 1}


func save_game(data: Dictionary) -> void:
    var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if file == null:
        push_warning("Could not open %s for writing (error %d)" % [SAVE_PATH, FileAccess.get_open_error()])
        return
    file.store_string(JSON.stringify(data))
    file.close()  # closing flushes the data to disk


func load_game() -> Dictionary:
    if not FileAccess.file_exists(SAVE_PATH):
        return DEFAULT_DATA.duplicate()
    var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
    if file == null:
        return DEFAULT_DATA.duplicate()
    var data = JSON.parse_string(file.get_as_text())
    file.close()
    if typeof(data) != TYPE_DICTIONARY:  # broken or empty save file
        return DEFAULT_DATA.duplicate()
    # Fill in any key that is missing (for example a save from an older version).
    for key in DEFAULT_DATA:
        if not data.has(key):
            data[key] = DEFAULT_DATA[key]
    return data


## Merges one finished run into the saved data, keeping the best values.
func record_run(score: int, combo: int, level_reached: int) -> void:
    var data := load_game()
    data["high_score"] = maxi(int(data["high_score"]), score)
    data["best_combo"] = maxi(int(data["best_combo"]), combo)
    data["highest_level"] = maxi(int(data["highest_level"]), level_reached)
    save_game(data)
