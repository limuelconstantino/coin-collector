# Coin Collector - Finals

Catch falling coins, dodge bombs, clear both levels.

## Open it
1. Open Godot 4 (the version your instructor set) -> Import -> select `project.godot`.
2. First open: Godot imports the sound files. Press F5 (main scene is the main menu).

## Controls
Move: WASD / Arrows - Dash: Space or Shift - Pause: P or Esc - Restart: R - Thread demo: T - Debug monitor: F2 - Leak test: F3

## What changed from the midterm
- Menu -> loading screen (threaded) -> Level 1 -> Level 2 -> win screen; lose screen with Restart / Menu.
- Power-ups: Shield (absorbs one hit/miss), Magnet (pulls coins, 8s), Slow-mo (halves fall speed, 6s).
- New Level 2 with bombs, new dash move, sound effects, unlockable level saved to `user://save.json`.
- Everything split into scenes/ folders; named Input Map actions; SaveManager and GameState autoloads.

## To do before submitting (I can't run Godot, so please test)
- [ ] Run once in the editor; check Output panel for errors.
- [ ] Measure and fill in `docs/MEMORY_REPORT.md`.
- [ ] Export: Editor > Manage Export Templates, then Project > Export > Add > Windows Desktop > turn off Export With Debug.
      Export to a folder OUTSIDE the project, run the .exe, and test saving and loading there.
- [ ] Update `CREDITS.txt`; fill in the `[Lastname]` / `[Section]` folder name for submission.
- [ ] Put the project on GitHub (the `.gitignore` already excludes `.godot/`).

Docs: `docs/EXPANSION_PLAN.md`, `docs/OS_CONCEPT_MAP.md`, `docs/MEMORY_REPORT.md`.
